export function compileTemplate() {
  // TODO
}
