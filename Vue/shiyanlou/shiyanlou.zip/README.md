- 项目架构， 目录
 1. api 前后端分离
    vue前端
    ajax 连接后端 axios
    /api/v2/products/:1
 2. pages components分离
 3. vuex store 设置？
 4. utils js 公共方法
 5. css/stylus stylus用的多牛逼
 20+ 页面的架构

- 路由
 lazyload
- page 组件化
- 页面由组件构成
  页面级组件 /pages
  可复用的组件 /components
    - 全站常用的公共组件，跟业务无关的 view  /components/common/
  容器组件
    PC页面量 切页面的工作交给组件化  html section概念来做
- App.vue 根组件， reset 工作  通用样式,
 界面 + 状态 = 完成开发
